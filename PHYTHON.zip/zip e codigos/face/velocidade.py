(input("digite o tempo e o espaço para descobrir a velelocidade media"))
s=float(input("espaço"))
t=float(input("tempo"))
v=((s)/t)

print("A velocidade media é ",v)
  

      
