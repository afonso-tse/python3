nome=(input("Digite o Primeiro Nome"))
sobrenome=(input("Digie o Segundo Nome"))
print(nome+sobrenome)





