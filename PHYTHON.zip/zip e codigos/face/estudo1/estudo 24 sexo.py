letra = input("Sexo:")
if (letra == "m" or letra== "M"):
    print ("Masculino")
elif (letra == "f" or "F"):
    print ("Feminino")
else:
    print ("Sexo invalido")

