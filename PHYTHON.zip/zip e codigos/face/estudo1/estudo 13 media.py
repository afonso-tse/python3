nota1=float(input("primeira nota"))
nota2=float(input("segunda nota"))
nota3=float(input("terceira nota"))
media=(nota1*4+nota2*5+nota3*6)/15
print("a media é:",media)
