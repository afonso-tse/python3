numero=float(input("Digite o nuúmero:"))
numero2=float(input("Digite o número:"))
soma=(numero+numero2)
print(soma)
