saldomedio=float(input("Sáldo Medio"))
if (saldomedio>=0 and saldomedio<=200):
   print("nem um credito")
elif(saldomedio>=201 and saldomedio<=400):
    credito=(saldomedio+0.2*saldomedio)
    print(credito,"20% do Sáldo medio")
elif(saldomedio>=401 and saldomedio<=600):
    credito=(saldomedio+0.3*saldomedio)
    print(credito,"30% do Sáldo medio")
elif(saldomedio>600):
    credito=(saldomedio+0.4*saldomedio)
    print(credito,"40% do Sáldo medio")

