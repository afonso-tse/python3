numero=float(input("primeiro numero"))
numero2=float(input("segundo Numero:"))
numero3=float(input("terceiro numero"))
if (numero > numero2):
    print ("maior:",numero)
elif (numero==numero2<numero3):
    print(numero,"igual",numero2,"maior",numero3)
elif (numero==numero3<numero2):
    print(numero,"igual",numero3,"maior",numero2)
elif (numero < numero2):
    print ("maior",numero2)
elif (numero > numero3):
     print ("maior",numero)
elif (numero < numero3):
     print ("maior",numero3)
elif (numero2 > numero3):
    print ("maior",numero2)
elif (numero2 < numero3):
    print ("maior",numero3)
else:
    print ("iguais")
if(numero2==numero3<numero):
 print(numero2,"igual",numero3,"maior",numero)
