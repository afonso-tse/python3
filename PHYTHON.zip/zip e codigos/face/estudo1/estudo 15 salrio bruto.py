SB=float(input("Salario Bruto: "))
H=float(input("Hora Extra: "))
h=H*10
INSS=(11/100*SB)
SL=(SB-INSS+H)
print("O Salario Liquido:",SL)
