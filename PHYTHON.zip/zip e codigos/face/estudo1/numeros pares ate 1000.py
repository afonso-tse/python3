cont = 0
while cont<1000:
 cont = cont + 2
 print ("%d" % (cont))
