nome=input("Digite o Nome: ")
idade=int(input("Digite a Idade: "))
telefone=int(input("Digite o Telefone: "))
print("Ola:",nome,"Você Tem",idade,"Anos","Seu Telefone é:",telefone) 



