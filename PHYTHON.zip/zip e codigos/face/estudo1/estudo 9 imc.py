altura=float(input("altura"))
sexo=input("Sexo")
m=((72.7*altura)-58)
if (sexo == "homem" or sexo== "M"):
    print (m,"homem")

else:
    f=((62.1*altura)-44.7)
    (sexo == "mulher")
    print (f,"Feminino")
