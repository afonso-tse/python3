k=float(input("quilometro"))
km=(k*1.609)
print(km, "milha")
