numero1 = float(input(" primeiro Numero:"))
numero2 = float(input(" segundo Numero:"))
if (numero1 > numero2):
    print ("maior:",numero1)
elif (numero1 < numero2):
    print ("maior",numero2)
else:
    print ("iguais")
