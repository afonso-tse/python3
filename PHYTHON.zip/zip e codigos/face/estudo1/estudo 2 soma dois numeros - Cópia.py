k=float(input("quilometros"))
km=(k*1.6)
print(km, "milhas")
