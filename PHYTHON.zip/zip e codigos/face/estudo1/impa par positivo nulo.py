numero=float(input("numero"))
if(numero>0):
      print("positivo")
elif(numero<0):
      print("nulo")
elif(numero==100):
      print("Igual")

if (numero%2==0):
      print ("Par")
else:
      print ("Impar")
