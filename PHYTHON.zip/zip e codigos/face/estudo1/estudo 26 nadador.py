idade=int(input("anos"))
if (idade >=5 and idade <= 7):
    print("nadador infatil A")          
elif (idade >=8 and idade <= 10):
    print("nadador infatil B") 
elif (idade >=11 and idade <= 13):
    print("nadador juvenil A")
elif (idade >=14 and idade <= 17):
     print("nadador juvenil B")
elif (idade >=18):
    print("nadador sênior")
          
