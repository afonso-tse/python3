idade=int(input("anos"))
if (idade <16):
    print("ivalidos")          
elif (idade ==16):
    print("Categoria A") 
elif (idade ==17):
    print("Categoria B")
elif (idade ==18):
     print("Categoria C")
elif (idade >18):
    print("ivalidos")
          
