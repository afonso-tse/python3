input('converter quilometro em milha')
k=float(input("quilometros"))
km=(k*1,6)
print ("é milha"km)

