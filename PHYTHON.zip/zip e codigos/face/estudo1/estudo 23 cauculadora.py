numero1=int(input("Numero:"))
numero2=int(input("Numero:"))
operacao=(input("operação:" ))
if(operacao=="+"):
    print(numero1+numero2)
elif (operacao=="-"):
    print(numero1-numero2)
elif (operacao=="*"):
    print(numero1*numero2)
elif (operacao=="/"):
    print(numero1/numero2)
else:
    print("Operação invalida")     
