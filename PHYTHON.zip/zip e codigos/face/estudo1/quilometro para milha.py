m=float(input("milha"))
mi=((m)/1.6)
print(mi, "quilometros")
