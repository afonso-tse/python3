numero=float(input("numero"))
if(numero>=100):
  print(numero)
elif(numero<100):
  print(0)
    
