valor=float(input("Valor"))         
print(int(valor/100),"Notas de Cem Reais")
valor=valor%100
print(int(valor/50),"Notas de Ciquenta Reais")
valor=valor%50
print(int(valor/20),"Notas de Vinte Reais")
balor=valor%20
print(int(valor/10),"Notas de Dez Reais")
valor=valor%10
print(int(valor/5),"Notas de Cinco Reais")
valor=valor%5
print(int(valor/2),"Notas de Dois Reais")
valor=valor%2
print(int(valor/1),"Moedas de um Real")
valor=valor%1
print(int(valor/0.50),"Moedas de Ciquenta Centavos")
valor=valor%0.50
print(int(valor/0.25),"Moedas de Vinte e Cinco Centavos")
valor=valor%0.25
print(int(valor/0.10),"Moedas de Dez Centavos")
valor=valor%0.10
print(int(valor/0.05),"Moedas de Cinco Centavos")
valor=valor%0.05
print(int(valor/0.01),"Moedas de Um Centavos")
valor=valor%0.01
