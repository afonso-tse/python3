dolar=float(input("Dólar:"))
"""converte o dólar em Real"""
D=2.3107*dolar
print("Ral:",D)
