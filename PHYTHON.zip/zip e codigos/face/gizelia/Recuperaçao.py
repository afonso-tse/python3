print(" A Média da Recueraçao é 7")
Nota1=float(input("Media"))
Nota2=(7-Nota1)
if (Nota2 <= 3): 
    print("Aprovado",Nota2)
else:
  if (Nota2 <=6):
    print("Recuperação",Nota2)
     
  else:  
    print("Reprovado",Nota2)


