Nota1=float(input("Primeira Nota"))
Nota2=float(input("Segunda Nota"))
Nota3=float(input("Tercira Nota"))
Nota4=float(input("Quarta Nota"))
Media=((Nota1+Nota2+Nota3+Nota4)/4)
if (Media >= 7): 
    print("Aprovado",Media)
else:
  if (Media <= 4):
    print("Reprovado",Media)
  else:  
    print("Recuperação",Media)
    Nota5=float(input("prova de Recuperacao: ",))
    Nota6=((Media+ Nota5)/2)
    if (Nota6 >= 5):
        print("Aprovado Primeira Nota:",Nota1,"Segunda Nota:",Nota2,"Terceira Nota:",Nota3,"Quarta Nota:",Nota4,"Recuperacão:",Nota5,"Nota Final:",Nota6)
    else:    
        print("Reprovado",Nota6)
