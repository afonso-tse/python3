Nota1=float(input("Primeira Nota"))
Media=((28-Nota1)/3)
print("Quanto Precisa para Passar, em Cada Bimestre",Media)

