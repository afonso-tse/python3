#Qust?o 14
custocarro=(float(input("Custo do Carro novo")))
distribuidor=0.28*custocarro
impostos=.45*custocarro
precofabrica=custocarro-impostos-distribuidor
print("Custo de Fábrica:",precofabrica)

