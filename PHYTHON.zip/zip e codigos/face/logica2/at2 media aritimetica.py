#Questão2
nota=(float(input("Primeira Nota")))
nota2=(float(input("Segunda Nota")))
nota3=(float(input("Terceira Nota")))
media=((nota+nota2+nota3)/3)
print(media,"Média")            
