#Qustão1
m=28*43
print(m)
