#Questão5
numero=(float(input("Número")))
n=((numero)/3)
print(n)

