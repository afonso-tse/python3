#Qustão6
numero=(float(input("Primeiro Número")))
numero2=(float(input("Segundo Número")))
print("Dividendo=",numero)
print("Divisor=",numero2)
n=numero/numero2
print("Quocinte=",n)
print("Resto=",numero%numero2)


