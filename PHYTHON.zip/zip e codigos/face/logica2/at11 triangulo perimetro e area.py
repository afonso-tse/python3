#Questão11
lado1=(float(input("Digite o valol do lado:")))
altura=(float(input("Digite o valor da altura:")))
base=(float(input("Digite o valor da  base:")))
area=(base*altura)/2
print("Área",area)
