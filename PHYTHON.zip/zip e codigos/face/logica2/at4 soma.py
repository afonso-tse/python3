#Questão4
numero=(float(input("Primeiro Número")))
numero2=(float(input("Segundo Número")))
n=(numero+numero2)
print("Soma=",n)
