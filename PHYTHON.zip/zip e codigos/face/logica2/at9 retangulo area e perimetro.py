#Questão9
lado1=float(input("Digite o valor do primeiro lado:")))
lado2=(float(input("Digite o valor do segundo lado:")))
lado3=(float(input("Digite o valor do terceiro lado:")))
lado4=(float(input("Digite o valor do quarto lado:")))
per=lado1+lado2+lado3+lado4
area=lado1*lado2
print ("Perímetro"per,"Área",area)
