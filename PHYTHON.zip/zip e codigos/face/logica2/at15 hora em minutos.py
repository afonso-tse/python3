#Questão15
H=(float(input("Hora")))
M=60
S=H*M
print("Já se pasaram",S,"Minutos")


