#Questão12
valor=(float(input("Valor")))
tempo=(float(input("Tempo")))
taxa=(float(input("Taxa")))
prestação=((valor)+((valor)*(taxa/100)))*tempo
print(prestação,"Prestação em Atraso")
