#Questão7
nota1=(float(input("Primeira Nota")))
nota2=(float(input("Segunda Nota")))
nota3=(float(input("Terseira Nota")))
nota4=(float(input("Quarta Nota")))
media=(nota1*1+nota2*2+nota3*3+nota4*4)/10
print(media)
