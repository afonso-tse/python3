#Qust?o13
A=(float(input("Altura")))
G=10
T=((A/G)**(1/2))
print("Tempo de Queda=",T)
