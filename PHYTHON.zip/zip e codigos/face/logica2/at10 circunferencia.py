#Questão10
raio=(float(input("Digite o valor do raio:")))
per=2*3.14*(raio)
area=3.14*(raio)**2
print("Perímetro",per,"Área",area)
