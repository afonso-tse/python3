#Questão8
S=float(input("Saldo"))
P=(S+0.01*S)
print(P,"Novo Saldo")
