#Qestão3
numero=float(input("Número"))
"""(x-1)(x)(x+1)"""
n=(numero+1)
print(n,"Sucessor")
u=(numero-1)
print(u,"Antecessor")

