"""nota=[]
for i in range(5):
    nome=input("nome")
    nota=input("nota")
    nota[nome]=nota
    print(nota)"""
aluno={'nome':'Alberto','idade':18}
print (aluno['nome'])

