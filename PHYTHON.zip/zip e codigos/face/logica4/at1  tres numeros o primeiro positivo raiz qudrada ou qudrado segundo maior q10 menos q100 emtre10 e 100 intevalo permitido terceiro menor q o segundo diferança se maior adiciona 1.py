numero=float(input("numero"))
numero2=float(input("segundo numero"))
numero3=float(input("terceiro numero"))
if (numero >=0):
    n=(numero)**(1/2)
    print("raiz quadrada do primeiro numero" ,n)
elif(numero<0):
    u=(numero)**2
    print("quadarado do  primeiro numero",u)
if(100>numero2>10):
    print("Número está entre 10 e 100 intervalo permitido")
if (numero3<numero2):
    m=numero3-numero2
    print("terceiro numero menos o segundo numero",m)
elif(numero3>numero2):
    r=(numero3+1)
    print("terceiro numero mais um",r)

