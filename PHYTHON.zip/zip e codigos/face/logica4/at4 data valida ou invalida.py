dia = int(input("Digite o dia "))
mes = int(input("Digite o mes "))
ano = int(input("Digite o ano "))

if(ano%4==0):
    
    if((mes == 1 or mes==3 or mes==5 or mes==7 or mes==8
        or mes==10 or mes==12) and not(dia >=1 and dia <= 31)):
        print("Data inválida")
    elif((mes==4 or mes ==6 or mes==9 or mes==11) and
         not(dia >=1 and dia <= 30)):
            print("Data inválida")
    elif((mes==2) and ( not(dia >=1 and dia <= 29))):
            print("Data inválida")
    else:
        print("Data válida")

else:
    if((mes == 1 or mes==3 or mes==5 or mes==7 or mes==8
        or mes==10 or mes==12) and not(dia >=1 and dia <= 31)):
        print("Data inválida")
    elif((mes==4 or mes ==6 or mes==9 or mes==11) and
         not(dia >=1 and dia <= 30)):
            print("Data inválida")
    elif((mes==2) and ( not(dia >=1 and dia <= 28))):
            print("Data inválida")
    else:
        print("Data válida")
