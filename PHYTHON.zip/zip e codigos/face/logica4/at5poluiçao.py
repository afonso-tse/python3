print("niveis toleraves é de 0.05 a 0.29")
industria=float(input("niveis"))
if (industria <=0.05 and industria <= 0.29):
    print("industia valida") 
elif (industria==0.3 ):
    print("industria1 é intimadas a suspenderem suas atividades") 
elif (industria ==0.4 ):
    print("industria1 e industria2 são intimadas a suspenderem suas atividades")
elif (industria >=0.5):
    print("todas as industrias1 2 3 devem ser notificadas a paralisarem suas atividades.")
