codigo=float(input("codigo do produto"))
quantidade=float(input("quntidade"))

if ((codigo==1001)or(codigo==987)):
    print (quantidade*5.32)

elif ((codigo==1324)or(codigo==7623)):
    print(quantidade*6.45)
elif (codigo==6548):
    print (quantidade*2.37)
else:
    print("invalido")
