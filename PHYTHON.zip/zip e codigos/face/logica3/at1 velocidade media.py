#Questão1
distancia=float(input("kilometros"))
hora=float(input("Hora"))
km=1000
h=3600
velocdade=((distancia/km)/(hora/h))
print(velocdade,"m/s")
