#Questão3
distancia=float(input("kilometros"))
milia=1.609#km
milia1=distancia/milia
print(milia1,"milia")
