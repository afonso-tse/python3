
#Questão5
ano=10
dia=365
ano1=52
dias=ano*365
semana=ano*ano1
print("dias",dias,"semana",semana)
