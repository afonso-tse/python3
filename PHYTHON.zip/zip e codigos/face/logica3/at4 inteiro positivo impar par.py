#Questão4
numero=int(input("numero"))
if (numero==0):
    print ("nulo")
if (numero>0):
    print ("Número positivo")
else:
    (numero<0)
    print ("Não é possivel")

if (numero%2==0):
	print ("Par")
else:
	print ("Impar")




























	


 
