#Questão2
idade=int(input("anos"))
if(idade==16):
    print("Ctegoria A")     
elif(idade<16):
    print("invalida")  
elif(idade ==17):
    print("invalida") 
elif(idade<17):
    print("invalida") 
elif (idade ==18):
    print("Categoria C")
elif(idade<18):
    print("invalida")     
