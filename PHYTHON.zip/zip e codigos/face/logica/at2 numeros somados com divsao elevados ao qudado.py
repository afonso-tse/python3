a = (float(input("Digite o valor de a:")))
b = (float(input("Digite o valor de b:")))
c = (float(input("Digite o valor de c:")))
r = (a+b)**2
s = (b+c)**2
d = ((r+s)/2)
print (d)
