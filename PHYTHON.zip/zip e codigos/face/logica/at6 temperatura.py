grau = (float(input("Digite o valor da temperatura em graus:\n")))
fah = grau *9/5 +32
print  (fah)
