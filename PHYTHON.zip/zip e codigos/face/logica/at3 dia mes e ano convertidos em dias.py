Anos = (int(input("Digite o valor de anos:")))
Meses = (int(input("Digite o valor de meses:")))
Dias = (int(input("Digite o valor de dias:")))
dia = Dias*1
meses = Dias*30
anos = Dias*365
dias = anos + meses + dia
print (dias)
