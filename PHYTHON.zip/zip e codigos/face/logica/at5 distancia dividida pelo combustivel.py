distancia = (float(input("Digite o valor da distancia percorrida:")))
combustivel = (float(input("Digite o valor do total de combustível:")))
total = distancia/combustivel
print (total)
