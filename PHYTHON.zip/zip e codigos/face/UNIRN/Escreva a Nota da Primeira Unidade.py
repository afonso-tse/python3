Nota1=float(input("Primeira Unidade"))
Media=((70-Nota1)/9)
print("Segunda Unidade",Media)
n=(Nota1+Media)
print(n)

