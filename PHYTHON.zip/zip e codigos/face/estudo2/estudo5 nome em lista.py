alunos = ["Fulano", "Cicrano", "Beltrano"]
print (alunos[0])
print (alunos[1])
print (alunos[2])
