nomes = ["Ana", "Carlos", "Eduardo", "Fernanda", "Geórgia", "Luiz"]
for x in nomes :
	print(x)
	i = 0
	while (i < len(x)):
  	         print (x[i])
  	         i = i + 1
