L = [1,2,3]
x=0
while x < len(L):
	print(L[x])
	x = x+1
