lista1=["a","b","c"]
print(len(lista1))
