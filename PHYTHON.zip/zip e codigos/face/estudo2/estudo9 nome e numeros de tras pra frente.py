aluno=["hecoles", 10,"afonso",12,"talles",13,"bruno",4,"tiago",10]
print(aluno[:-1])
