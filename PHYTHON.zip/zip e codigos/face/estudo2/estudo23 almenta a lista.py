lista = []
num = int(input("Digite um número ou 0 para parar"))
while (num != 0):
	lista.append(num)
	num = int(input("Digite um número ou 0 para parar"))
print ("Todos os números digitados foram: ")
for x in lista:
	print(x)
