while 1==1:
    n= int(input("numero: "))
    if n>0:
        print (n)
    elif n<=0:
        break
