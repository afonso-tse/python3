L=list(range(0,101))
print(L)
