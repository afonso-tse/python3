alunos = ["Fulano", "Cicrano", "Beltrano", "afonso", "lucas"]
print (alunos[0])
print (alunos[4])

