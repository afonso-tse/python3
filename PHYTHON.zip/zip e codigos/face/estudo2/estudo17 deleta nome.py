L = ["a","b","c"]
del L[0]
print (L)
