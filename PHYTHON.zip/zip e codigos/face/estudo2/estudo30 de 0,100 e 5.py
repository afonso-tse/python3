L = list( range(0, 100, 5) )
for x in L:
	(print L)
