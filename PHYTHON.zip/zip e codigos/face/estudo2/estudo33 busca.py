lista = [1,2,3,4,5,6,7,8,9,10]
busca = int(input("Qual número você quer buscar? "))
achou = False
x = 0
while x<len(lista):
       if lista[x]==busca:
            achou = True
            break
       x = x+1

if achou:
    print ("O elemento foi achado na posição",x)
else:
    print ("O elemento não foi achado na lista")
