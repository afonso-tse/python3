L = [1,2,3,4,5,6,7,8,9,10]
x=0
while x < len(L):
	print(L[x])
	x = x+1
