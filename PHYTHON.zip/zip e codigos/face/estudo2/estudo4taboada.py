while 1==1:

    print("Multiplicar = *", "Dividir= /", "Subitrair = -", "Somar= +", "Sair=sair")


    c=(input("Digite a Operação que Você quer a Tabuada: "))
    t=1
    if (c=="*"):
        while t<=10:
            n=1
            while n<=10:
                print(t ,"*",n,"=",t*n)
                n=n+1
            t=t+1
            print ("\n")
    elif (c=="-"):
        while t<=10:
            n=1
            while n<=10:
                print(t ,"-",n,"=",t-n)
                n=n+1
            t=t+1
            print ("\n")
    elif (c=="+"):
        while t<=10:
            n=1
            while n<=10:
                print(t ,"+",n,"=",t+n)
                n=n+1
            t=t+1
            print ("\n")
    elif (c=="/"):
        while t<=10:
            n=1
            while n<=10:
                print(t ,"/",n,"=",t/n)
                n=n+1
            t=t+1
            print ("\n")
    elif c=="sair" or c=="Sair":
        break



