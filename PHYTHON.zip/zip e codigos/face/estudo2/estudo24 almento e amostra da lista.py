lista_produtos = []

continuar = True
while (continuar):
    nome = input("Informe o nome do produto ou 0 parar: ")
    if(nome == "0"):
        continuar = False
    else:
        valor = (input("Informe o valor do produto: "))
        quantidade = int(input("Informe a quantidade do produto: "))
        produto = [nome, quantidade, valor]
        lista_produtos.append(produto)

#print produtos
i = 0
while(i < len(lista_produtos)):
    print ("Produto: ", lista_produtos[i][0])
    print ("Quantidade: ", lista_produtos[i][1])
    print ("Valor: R$ ", lista_produtos[i][2], )
    i = i+1
