aluno=["bianca", "afonso", "tse","maria","joao","jose","bruno","tiago","lucia","bernardo"]
print(aluno[0])
print(aluno[9])
