L = ["A","B","C"]
x=0
while x <3:
	print(L[x])
	x = x+1
