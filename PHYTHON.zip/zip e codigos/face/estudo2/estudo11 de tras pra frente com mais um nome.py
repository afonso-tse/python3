aluno=["hecoles","afonso","talles","bruno","tiago"]+["lucas"]
print(aluno[:-1])
