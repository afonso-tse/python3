L = ["a","b","c","d", "e", "f"]
del L[0:4]
print (L)
