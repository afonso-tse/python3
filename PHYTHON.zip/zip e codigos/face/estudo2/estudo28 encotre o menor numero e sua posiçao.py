Lista = []
x= int(input("Digite um valor positivo"))
while(x>=0):
    Lista.append(x)
    x= int(input("Digite um valor positivo"))

menor = Lista[0]

i=0
while(i<len(Lista)):
    if(Lista[i] < menor):
        menor = Lista[i]
    i = i+1
print("O menor elemento eh", menor)





