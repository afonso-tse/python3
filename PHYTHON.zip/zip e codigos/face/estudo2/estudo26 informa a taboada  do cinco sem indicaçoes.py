lista=range(11)
for x in lista:
    print ( x * 5)
