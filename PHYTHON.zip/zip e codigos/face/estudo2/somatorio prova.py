contador=1
somatorio=0
while(contador<=6):
    contador=contador+1
    numero=float(input("valor"))
    somatorio=somatorio+numero
print("somatorio",somatorio)
