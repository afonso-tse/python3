seq = [1,2,3,4,5,6,7,8,9,10]
busca = float(input("Qual número você quer buscar? "))

encontrou = -1
direita = len(seq) - 1
esquerda = 0

while (esquerda <= direita and encontrou < 0):
       centro = (esquerda + direita)/2
       valor_centro = seq[centro]
       if busca == valor_centro:
              encontrou = centro
              break
       elif busca < valor_centro:
              direita = centro - 1
       else:
              esquerda = centro + 1

if encontrou > -1:
       print ("encontrou o valor na posição ", encontrou)
else:
       print ("O valor procurado não existe na lista")
