dia=int(input("Dia:"))
mes=int(input("Mês:"))
ano=int(input("Ano:"))
if(dia<=31 and mes==1):
    print("Data válida.")
elif(dia>31 and mes==1):
    print("Data inválida.")
elif(dia<=28 and mes==2):
    print("Data válida.")
elif(dia>28 and mes==2):
    print("Data inválida.")
elif(dia<=30 and mes==3):
    print("Data válida.")
elif(dia>30 and mes==3):
    print("Data inválida.")
elif(dia<=31 and mes==4):
    print("Data válida.")
elif(dia>31 and mes==4):
    print("Data inválida.")
elif(dia<=31 and mes==5):
    print("Data válida.")
elif(dia>31 and mes==5):
    print("Data inválida.")
elif(dia<=30 and mes==6):
    print("Data válida.")
elif(dia>30 and mes==6):
    print("Data inválida.")
elif(dia<=31 and mes==7):
    print("Data válida.")
elif(dia>31 and mes==7):
    print("Data inválida.")
elif(dia<=31 and mes==8):
    print("Data válida.")
elif(dia>31 and mes==8):
    print("Data inválida.")
elif(dia<=30 and mes==9):
    print("Data válida.")
elif(dia>30 and mes==9):
    print("Data inválida.")
elif(dia<=31 and mes==10):
    print("Data válida.")
elif(dia>31 and mes==10):
    print("Data inválida.")
elif(dia<=30 and mes==11):
    print("Data válida.")
elif(dia>30 and mes==11):
    print("Data inválida.")
elif(dia<=31 and mes==12):
    print("Data válida.")
elif(dia>31 and mes==12):
    print("Data inválida.")
else:
    ano=int(input("Ano:"))
    if(dia==29 and ano%4!=0):
        print("Data inválida.")
    else:
        print("Data válida.")
