numero=(float(input("Número")))
n=2
n3=numero%n
print(n3,"Impar")
