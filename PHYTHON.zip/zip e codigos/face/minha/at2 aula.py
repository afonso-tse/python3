nota=float(input("Primeira Nota"))
nota2=float(input("Segunda Nota"))
aulasministradas=float(input("Aulas Ministradas"))
aulasassistidas=float(input("Aulas Assistida"))
falta=int(input("Faltas"))
Media=((nota*4+nota2*6)/10)
if (Media >= 6): 
    print("Aprovado")
else:
  if (Media < 6):
    print("Reprovado")
  
