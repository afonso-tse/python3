"""x=int(input("Informe quantos numeros serão impressos em ordem decrescente"))
while(x>=0):
    print(x)
    x=x-1"""
"""x=int(input("Informe um número para calculo fatorial"))
fat=1
while(x>=1):
    fat=fat*x
    x=x-1
print(fat)"""
while 1==1:
    x=int(input("Digite a operação"))
    tabuada=1
    if(x=="+"):
        while tabuada<=10:
            numero=1
            while numero<=10:
            print(tabuada,"+",numero,"=",tabuada+numero)
                numero=numero+1
            tabuada=tabuada+1

    
