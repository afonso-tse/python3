s=float(input("n"))
if (s>0):
n=s**(1/2)
print(n)
