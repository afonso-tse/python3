dia,mes,ano =input("data (dd/mm/aaa):").split("/")
meses=["janeiro", "feveriro","março","abril","maio","junho","julho","agosto",
       "setembro","outubro","novenbro","dezenbro"]
print("nasce")
print("%s de %s de %s"%(dia,meses[int(mes)-1],ano))

