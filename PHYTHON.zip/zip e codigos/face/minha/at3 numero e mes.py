dia=int(input("Dia:"))
mes=input("Mês:")
if (dia<=31 and mes==janeiro):
    print("Data válida.")
