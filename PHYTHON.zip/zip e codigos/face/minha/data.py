
dia=int(input("Dia:"))
mes=int(input("Mês:"))
ano=int(input("Ano:"))
if (ano%4==0):
      
      if((mes==1 or mes==3 or mes==5 or mes==7 or mes==8or mes==10 or mes==12) and
         (dia>=1 and dia<=31)):
      print("data invalida")
      elif((mes==2) and (dia<=29)):
          print("data invalida")
      elif((mes==4 or mes==6 or mes==9 or mes==11) and (dia<=30)):
      print("data valida")
      
      print("data invalida")
      else:
      print("data valida")
      
      
