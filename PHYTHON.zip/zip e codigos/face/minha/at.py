while True:
    numero=float(input("qual quer numero ou zero para parar"))
    if (numero==0):
       break
    else:
        print(numero)
