dia=int(input("Dia:"))
mes=int(input("Mês:"))
ano=int(input("Ano:"))
if(ano%4==0):
      if((mes==1 or mes==3 or mes==5 or mes==7 or mes==8
          or mes==10 or mes==12) and (dia<=31)):
      print("data valida")
      else:
          print("Invalda")
      elif((mes==4 or mes==6 or mes==9 or mes==11) and (dia<=30)):
      print("data valida")
      elif((mes==2) and (dia<=28)):
      print("data valida")
      else:
      print("data valida")
      else:
      if(mes==1 or mes==3 or mes==5 or mes==7 or mes==8 or mes==10 or mes==12) and (dia<=31):
      print("data valida")
      elif(mes==4 or mes==6 or mes==9 or mes==11) and (dia<=30):
      print("data valida")
     elif((mes==2) and (dia<=29)):
     print("data valida")
     else:
     print("data ivalida")

