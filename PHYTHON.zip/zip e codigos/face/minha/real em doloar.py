real=float(input("Real:"))
"""converte o real em dólar"""
R=2.3107/real
print("Dólar:",R)

