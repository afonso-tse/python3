s=float(input("espaço"))
t=float(input("tempo"))
v=((s)/t)

    print("A velocidade media é ",v)
  

      
