A1 = []
A2 = []
A3 = []

i = 0
while(i<5):
    x = int(input("Digite um valor para a primeira lista"))
    A1.append(x)
    A3.append(x)
    i = i+1

i = 0
while(i<5):
    x = int(input("Digite um valor para a segunda lista"))
    A2.append(x)

    j=0
    existe=False
    while(j<len(A3)):
        if(A3[j]==x):
            existe=True
        j=j+1

    if(not existe):
        A3.append(x)
    
    i = i+1

i=0
while(i<len(A3)):
    print(A3[i])
    i = i+1
