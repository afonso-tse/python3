lista=[]
x= int(input("Digite um valor do produto"))
while(x>=0):
    lista.append(x)
    x= int(input("Digite um valor do produto"))


i=0
while(i<len(lista)):
    if(lista[i]>10):
        print(lista[i])
    i = i+1

