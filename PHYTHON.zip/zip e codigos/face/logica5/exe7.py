lista = []

i=0
while(i<5):
    x = int(input("Digite um valor para a lista"))
    lista.append(x)
    i = i+1

pares = 0
impares=0
i=0
while(i<5):
    if(lista[i]%2 == 0):
        pares = pares + 1
    else:
        impares = impares + 1
    i=i+1

print("Pares =", pares, "Impares =", impares)
