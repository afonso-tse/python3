Lista = []
i = 0
while(i<10):
    x = float(input("Digite um valor para a lista"))
    Lista.append(x)
    i = i+1

posicao_menor = 0
i=0
while(i<len(Lista)):
    if(Lista[i] < Lista[posicao_menor]):
        posicao_menor = i
    i = i+1

print("O menor elemento eh", Lista[posicao_menor])
print("A posicao do menor elemento eh", posicao_menor)
