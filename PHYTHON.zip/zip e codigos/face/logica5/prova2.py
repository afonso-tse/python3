Lista = []
x= int(input("Digite um valor positivo"))
while(x>=0):
    Lista.append(x)
    x= int(input("Digite um valor positivo"))

menor = Lista[0]
maior = Lista[0]
soma = 0
i=0
while(i<len(Lista)):
    if(Lista[i] < menor):
        menor = Lista[i]
    if(Lista[i] > maior):
        maior = Lista[i]
    soma = soma + Lista[i]
    i = i+1

print("O menor elemento eh", menor)
print("O maior elemento eh", maior)
print("A media dos elementos eh", (soma/len(Lista)))
