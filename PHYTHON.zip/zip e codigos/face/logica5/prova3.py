lista=[]
i = 0
while(i<5):
    x = float(input("Digite um salário"))
    if(x<1000):
        x = x*1.1
    lista.append(x)
    i = i+1

i=0
while(i<len(lista)):
    print(lista[i])
    i = i+1
