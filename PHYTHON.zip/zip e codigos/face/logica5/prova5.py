nomes=[]
i = 0
while(i<10):
    x = input("Digite um nome")
    nomes.append(x)
    i = i+1

nomes.sort()

print(nomes)
