soma=0
cont=0
print("digite o valor")
x= int(input("Digite um valor do produto"))
while (x>0):
    soma=soma+x
    cont=cont+1
    print("digite o valor")
    x= int(input("Digite um valor do produto")
        if(cont>=1)
        else
        media=soma/cont
        print(media)
        elif print("nem um valor digitado")
    
    
