cont=0
while cont<=99:
    cont = cont + 1
    print (cont)
