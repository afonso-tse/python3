Lista = [1,2,3,4,5,6,7,8,9,10]
menor = Lista[0]
i=0
while(i<len(Lista)):
    if(Lista[i] < menor):
        menor = Lista[i]
    i = i+1
print("O menor elemento eh", menor)


