cont=1
soma=0
while (cont<=20):
    num=float(input("digite o numero:"))
    soma=soma+num
    cont= cont+1
print("A somatoria dos numeros é: ",soma)
