contador=1 
while(contador<=10):
    mutiplicado=9*contador
    print("9*","=",mutiplicado)
    contador=contador+1
