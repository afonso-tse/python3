num=100
while num>=1:
    print(num)
    num= num - 1
