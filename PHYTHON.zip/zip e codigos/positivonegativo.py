#!/usr/bin/env python
n = int(input("digite um numero: "))
if (n>=0):
  elif (n%2==0):
    print ("positivo")
else:
  print ("negativo")
