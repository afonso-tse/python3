a = int(input('Digite um numero: '))
if (a%2==0):
        print ("Par")
elif (s>0):
	
else:
	print ("Impar")
else:
        print("Saldo nulo")
