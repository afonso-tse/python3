Nota1=float(input("Primeira Nota"))
m=((80-Nota1)/9)
print("Quanto Precisa para Passar, em Cada Bimestre",m)
p=(m+Nota1)
print(p)

