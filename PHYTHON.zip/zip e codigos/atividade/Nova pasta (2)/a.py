Nota1=float(input("Primeira Unidade"))
Media=((Nota1-60)/10)
print("Segunda Unidade",Media)
#4*nota+6*nota/10
#nota-60*nota
