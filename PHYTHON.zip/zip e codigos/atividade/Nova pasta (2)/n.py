Nota1=float(input("Primeira Nota"))
x=((21-Nota1)/2)
print (x)
x+y+z/3
