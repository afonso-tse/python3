Nota1=float(input("Primeira Nota"))
Media=((21-Nota1)/2)
print("Quanto Precisa para Passar, em Cada Bimestre",Media)


