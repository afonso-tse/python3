Nota1=float(input("Primeira Nota"))
Nota2=float(input("Segunda Nota"))
Media=(Nota1*40+Nota2*60)
if (Media >= 7): 
    print("Aprovado",Media)
else:
  if (Media <= 3):
    print("Reprovado",Media)
  else:  
    print("Recuperação",Media)
    Nota3=float(input("prova de recuperacao: "))
    Nota4=(Nota3-10)
    if (Nota4 >= 5):
        print("Aprovado,Primeira Nota:",Nota1,"Segunda Nota:",Nota2,"Recuperação:",Nota3,"Nota final",Nota4)
    else:    
        print("Reprovado","Primeira Nota:",Nota1,"Segunda Nota:",Nota2,"Recuperação:",Nota3,"Nota final",Nota4)

