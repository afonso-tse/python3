import prova2
import primo

print("media do aluno" + prova2.aprova)
print("numeo primo" + primo.primo)
