def primo(n):
    teste=1
    for i in range(2,n):
        if n %i==0:
            teste+=1
    if teste!=1:
        return False
    else:
        return True
x=int(input("Número"))
print(primo(x))
