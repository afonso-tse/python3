def aprova(nota1,nota2):
    notafinal=(((nota1*4)+(nota2*6))/10)
    if notafinal >=7:
        return("APROVADO",notafinal)
    elif notafinal <=3:
        return("REPROVADO",notafinal)
    elif notafinal >3 and notafinal <7:
        return("RECUPERAÇÃO",notafinal)
nota1=float(input("Digite a primeira nota:"))
nota2=float(input("Digite a segunda nota:"))
print (str(aprova(nota1,nota2)))
