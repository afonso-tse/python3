while True:
    a = int(input('Digite um numero: '))
if (a==0):
elif (a%2==0):

       break

       print ("Par")
else:
        print("impa")
