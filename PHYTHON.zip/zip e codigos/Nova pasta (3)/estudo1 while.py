while True:
    numero=float(input("qual quer numero ou zero para parar"))
    if (numero%2==0):
       break
    print ("Par")
else:
    print("impa")
