numero=float(input("numero"))
numero2=float(input("numero"))
numero3=float(input("numero"))
if(numero>numero2):
      print("nota 1 é maior", numero)
elif(numero<numero2):
      print("nota 2 é maior", numero2)
elif(numero<numero3):
     print("nota 3 é maior que nota 1", numero3)
elif(numero==numero2 and numero2==numero3 and numero==numero3):
       print("Igual")
elif(numero==numero2):
      print(" primeira e segunda são Iguais")

if (numero%2==0):
      print ("Par")
else:
      print ("Impar")
