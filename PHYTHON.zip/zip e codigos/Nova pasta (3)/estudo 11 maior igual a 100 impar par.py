numero=float(input("numero"))
if(numero>100):
      print("Maior que 100")
elif(numero<100):
      print("Memor que 100")
elif(numero==100):
      print("Igual")

if (numero%2==0):
      print ("Par")
else:
      print ("Impar")
