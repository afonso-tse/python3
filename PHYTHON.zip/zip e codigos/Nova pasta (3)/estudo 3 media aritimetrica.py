nota1=float(input("Digite a Nota:"))
nota2=float(input("Digite a Nota:"))
nota3=float(input("Digite a Nota:"))
media=((nota1+nota2+nota3)/3)
print(media)

