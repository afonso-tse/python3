contador=1
somatorio=0
while True:
    contador=contador+1
    numero=float(input("qual quer numero ou zero para parar"))
    if (numero==0):
       break
    somatorio=somatorio+numero
print("somatorio",somatorio)
