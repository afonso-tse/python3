s = float(input("Digite o saldo da sua conta:" ))
if (s>0):
       print ("Saldo positivo")
else:
        print("Saldo nulo")
    
