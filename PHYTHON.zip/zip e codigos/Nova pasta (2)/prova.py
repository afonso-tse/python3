def aprova (n1,n2):
    if ((n1*4)+(n2*6))/10>=7:
return ("Aprovado")

elif ((n1*4)+(n2*6))/10>3<7:
return ("Recuperação")

else:
return "Reprovado"

nome= input ("Digite um nome: ")
h1= int (input("Digite 1ª nota: "))
h2= int (input("Digite 2ª nota: "))
print ("O aluno ",nome," está",aprova(h1,h2))
