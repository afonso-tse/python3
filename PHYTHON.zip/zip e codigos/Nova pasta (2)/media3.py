Nota1=float(input("Primeira Nota"))
x=((70-Nota1)/9)
print (x)
