numero = int(input("Digite um numero:"))
if (numero%2==0):
	print ("Par")
else:
	print ("Impar")
