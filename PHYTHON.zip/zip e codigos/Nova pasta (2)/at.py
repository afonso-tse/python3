
def primo(n):
    teste=1
    for i in range(2,n):
        if n %i==0:
            teste+=1
    if teste!=1:
        return False
    else:
        return True
x=float(input("Número"))
print(primo(x))
"""
import sys
for i in sys. path:
 print (i)
"""
