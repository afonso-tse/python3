a = int(input('Digite um numero: '))
if (a%2==0):
	print ("Par")
else:
	print ("Impar")
