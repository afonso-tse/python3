"""biblioteca=[]
continua=True
while(continua):
    titulo= input("informe o titulo ou 0 parar")
    if(titulo==0)
    continua=False
    else:
        quantidade=int(input("quatidade"))
        autor=input("autor")
        livro[titulo,quantidade,autor]
        biblioteca.append(livro)
        i=0
        while(i<len(biblioteca)):
           print("livro",biblioteca[i][0])
           print("quntidade",biblioteca[i][1])
           print("auto",(biblioteca[i][2]*biblioteca[i][1])
                 i=i+1"""
"""lista=[1,2,3]
	x=0
	while(x<len(lista)):
            elem=lista[x]
            print(elem)
            x=x+1"""
"""nomes = ["Ana", "Carlos", "Eduardo", "Fernanda", "Geórgia", "Luiz"]
for x in nomes :
	print(x)"""
"""L = list(range(0, 100, 5))
for x in L:
	(print x)"""
